import React, { useState, useEffect, useMemo } from 'react';
import { Edit, Trash2 } from 'lucide-react';
import { getEquipments, saveEquipments, saveEquipment } from '../../utils/storageManager';
import { generateId } from '../../utils/helpers';
import DataTable from '../../components/DataTable';
import ModalAlert from '../../components/ModalAlert';
import ModalForm from '../../components/ModalForm';

export default function ListofEquipment({ searchQuery, triggerAdd }) {
  const [equipments, setEquipments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(15);
  
  const [alertConfig, setAlertConfig] = useState({ isOpen: false, type: 'success', title: '', message: '', onConfirm: () => {} });

  const [formData, setFormData] = useState({
    id: '', equipmentName: '', makeModel: '', instSrNo: '', rangeSize: '', leastCount: '', dateOfPurchase: ''
  });

  const headers = ['Actions', 'Timestamp', 'ID No.', 'Equipment Name', 'Make/ Model', 'Inst. Sr.No', 'Range/ Size', 'Least Count', 'Date of Purchase'];

  useEffect(() => {
    setEquipments(getEquipments());
  }, []);

  useEffect(() => {
    if (triggerAdd > 0) handleAdd();
  }, [triggerAdd]);

  const filteredEquipments = useMemo(() => {
    return equipments.filter(eq => {
      const q = searchQuery.toLowerCase();
      return (
        eq.id?.toLowerCase().includes(q) ||
        eq.equipmentName?.toLowerCase().includes(q) ||
        eq.makeModel?.toLowerCase().includes(q) ||
        eq.instSrNo?.toLowerCase().includes(q)
      );
    });
  }, [equipments, searchQuery]);

  const sortedEquipments = useMemo(() => [...filteredEquipments].reverse(), [filteredEquipments]);
  const totalPages = Math.ceil(sortedEquipments.length / itemsPerPage);
  const paginatedEquipments = sortedEquipments.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleAdd = () => {
    setEditingId(null);
    setFormData({ id: '', equipmentName: '', makeModel: '', instSrNo: '', rangeSize: '', leastCount: '', dateOfPurchase: '' });
    setShowModal(true);
  };

  const handleEdit = (eq) => {
    setEditingId(eq.internalId);
    setFormData({ ...eq });
    setShowModal(true);
  };

  const showAlert = (type, title, message, onConfirm = () => {}) => {
    setAlertConfig({ isOpen: true, type, title, message, onConfirm });
  };

  const handleDelete = (internalId) => {
    showAlert('confirm', 'Delete Equipment?', 'Are you sure you want to delete this equipment?', () => {
      const updated = equipments.filter(e => e.internalId !== internalId);
      saveEquipments(updated);
      setEquipments(updated);
      showAlert('success', 'Deleted!', 'Equipment has been successfully removed.');
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingId) {
      const updated = equipments.map(eq => eq.internalId === editingId ? { ...eq, ...formData } : eq);
      saveEquipments(updated);
      setEquipments(updated);
      showAlert('success', 'Updated!', 'Equipment details have been modified successfully.');
    } else {
      const newEq = {
        ...formData,
        internalId: `EQ-${Date.now()}`,
        timestamp: new Date().toISOString()
      };
      saveEquipment(newEq);
      setEquipments([...equipments, newEq]);
      showAlert('success', 'Created!', 'New equipment has been added to the database.');
    }
    setShowModal(false);
  };

  const formatTimestamp = (isoString) => {
    if (!isoString) return '';
    const date = new Date(isoString);
    return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}`;
  };

  const renderRow = (item) => (
    <tr key={item.internalId} className="hover:bg-gray-50 transition-colors text-center text-sm border-b border-gray-100">
      <td className="px-4 py-2 whitespace-nowrap">
        <div className="flex items-center justify-center gap-2">
          <button onClick={() => handleEdit(item)} className="text-indigo-600 hover:text-indigo-800 transition-colors"><Edit size={14}/></button>
          <button onClick={() => handleDelete(item.internalId)} className="text-red-500 hover:text-red-700 transition-colors"><Trash2 size={14}/></button>
        </div>
      </td>
      <td className="px-4 py-2 text-gray-600 whitespace-nowrap text-[11px] md:text-xs">{formatTimestamp(item.timestamp)}</td>
      <td className="px-4 py-2 text-gray-900 font-bold whitespace-nowrap text-[11px] md:text-xs">{item.id}</td>
      <td className="px-4 py-2 text-gray-700 whitespace-nowrap text-[11px] md:text-xs text-left max-w-[200px] truncate" title={item.equipmentName}>{item.equipmentName}</td>
      <td className="px-4 py-2 text-gray-700 whitespace-nowrap text-[11px] md:text-xs text-left">{item.makeModel}</td>
      <td className="px-4 py-2 text-gray-700 whitespace-nowrap text-[11px] md:text-xs">{item.instSrNo}</td>
      <td className="px-4 py-2 text-gray-700 whitespace-nowrap text-[11px] md:text-xs">{item.rangeSize}</td>
      <td className="px-4 py-2 text-gray-700 whitespace-nowrap text-[11px] md:text-xs">{item.leastCount}</td>
      <td className="px-4 py-2 text-gray-700 whitespace-nowrap text-[11px] md:text-xs">{item.dateOfPurchase}</td>
    </tr>
  );

  const renderCard = (item) => (
    <div key={item.internalId} className="bg-white p-3 rounded-lg border border-gray-200 shadow-sm space-y-3">
      <div className="flex justify-between items-start border-b border-gray-100 pb-2">
        <div>
          <span className="text-[9px] font-medium text-indigo-600 uppercase tracking-widest">{item.id}</span>
          <h3 className="text-sm font-medium text-gray-700 leading-tight">{item.equipmentName}</h3>
        </div>
        <div className="flex gap-2">
          <button onClick={() => handleEdit(item)} className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg"><Edit size={14}/></button>
          <button onClick={() => handleDelete(item.internalId)} className="p-1.5 bg-red-50 text-red-500 rounded-lg"><Trash2 size={14}/></button>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 text-[11px]">
        <div className="space-y-0.5"><p className="text-[9px] text-gray-400 font-bold uppercase">Make / Model</p><p className="font-bold text-gray-700 truncate">{item.makeModel}</p></div>
        <div className="space-y-0.5 text-right"><p className="text-[9px] text-gray-400 font-bold uppercase">Inst. Sr.No</p><p className="font-bold text-gray-700">{item.instSrNo}</p></div>
        <div className="space-y-0.5"><p className="text-[9px] text-gray-400 font-bold uppercase">Range / Size</p><p className="font-bold text-gray-700">{item.rangeSize}</p></div>
        <div className="space-y-0.5 text-right"><p className="text-[9px] text-gray-400 font-bold uppercase">Least Count</p><p className="font-bold text-gray-700">{item.leastCount}</p></div>
      </div>
      <div className="pt-2 border-t border-gray-50 flex justify-between">
        <span className="text-[10px] text-gray-400 font-medium">{formatTimestamp(item.timestamp)}</span>
        <span className="text-[10px] text-gray-500 font-medium">Purchased: {item.dateOfPurchase}</span>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-full min-h-0">
      <DataTable 
        headers={headers} 
        data={paginatedEquipments}
        renderRow={renderRow}
        renderCard={renderCard}
        minWidth="1000px"
        currentPage={currentPage}
        totalPages={totalPages}
        itemsPerPage={itemsPerPage}
        totalResults={filteredEquipments.length}
        onPageChange={setCurrentPage}
        onItemsPerPageChange={(val) => { setItemsPerPage(val); setCurrentPage(1); }}
      />

      <ModalAlert 
        {...alertConfig} 
        onClose={() => setAlertConfig({ ...alertConfig, isOpen: false })} 
      />

      <ModalForm
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={editingId ? 'Edit Equipment' : 'Add New Equipment'}
        onSubmit={handleSubmit}
        submitText={editingId ? 'Update' : 'Save'}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="block text-[10px] md:text-[12px] text-gray-700 uppercase tracking-tight">ID No. *</label>
            <input required type="text" value={formData.id} onChange={(e) => setFormData({...formData, id: e.target.value})} className="w-full border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-[11px] md:text-[13px] h-[30px] md:h-[34px]" placeholder="e.g. DEIPL/M/D/01" />
          </div>
          <div className="space-y-1 md:col-span-2">
            <label className="block text-[10px] md:text-[12px] text-gray-700 uppercase tracking-tight">Equipment Name *</label>
            <input required type="text" value={formData.equipmentName} onChange={(e) => setFormData({...formData, equipmentName: e.target.value})} className="w-full border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-[11px] md:text-[13px] h-[30px] md:h-[34px]" placeholder="e.g. Gauge Block" />
          </div>
          <div className="space-y-1">
            <label className="block text-[10px] md:text-[12px] text-gray-700 uppercase tracking-tight">Make / Model</label>
            <input type="text" value={formData.makeModel} onChange={(e) => setFormData({...formData, makeModel: e.target.value})} className="w-full border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-[11px] md:text-[13px] h-[30px] md:h-[34px]" />
          </div>
          <div className="space-y-1">
            <label className="block text-[10px] md:text-[12px] text-gray-700 uppercase tracking-tight">Inst. Sr.No</label>
            <input type="text" value={formData.instSrNo} onChange={(e) => setFormData({...formData, instSrNo: e.target.value})} className="w-full border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-[11px] md:text-[13px] h-[30px] md:h-[34px]" />
          </div>
          <div className="space-y-1">
            <label className="block text-[10px] md:text-[12px] text-gray-700 uppercase tracking-tight">Range / Size</label>
            <input type="text" value={formData.rangeSize} onChange={(e) => setFormData({...formData, rangeSize: e.target.value})} className="w-full border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-[11px] md:text-[13px] h-[30px] md:h-[34px]" />
          </div>
          <div className="space-y-1">
            <label className="block text-[10px] md:text-[12px] text-gray-700 uppercase tracking-tight">Least Count</label>
            <input type="text" value={formData.leastCount} onChange={(e) => setFormData({...formData, leastCount: e.target.value})} className="w-full border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-[11px] md:text-[13px] h-[30px] md:h-[34px]" />
          </div>
          <div className="space-y-1">
            <label className="block text-[10px] md:text-[12px] text-gray-700 uppercase tracking-tight">Date of Purchase</label>
            <input type="text" value={formData.dateOfPurchase} onChange={(e) => setFormData({...formData, dateOfPurchase: e.target.value})} className="w-full border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-[11px] md:text-[13px] h-[30px] md:h-[34px]" placeholder="e.g. Sep-20" />
          </div>
        </div>
      </ModalForm>
    </div>
  );
}
